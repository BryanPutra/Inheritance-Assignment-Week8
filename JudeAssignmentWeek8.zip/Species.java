
public class Species extends Genus{
	private String speciesName;
	
	public Species(String s, String g) {
		super(g);
		this.speciesName = s;
	}
	public String getSpeciesName() {
		return speciesName;
	}
	public void setSpeciesName(String speciesName) {
		this.speciesName = speciesName;
	}
	@Override
	public String toString() {
		return "Species: " + getGenusName() + " " + speciesName;
	}
	public boolean equals(Species s) {
		return speciesName.equals(s.getSpeciesName());
	}
}
