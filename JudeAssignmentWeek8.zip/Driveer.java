
public class Driveer {
	public static void main(String [] args) {
		Shape s1 = new Shape();
		Shape s2 = new Shape("green", false);
		System.out.println(s1.getColor() + s1.isFilled());
		System.out.println(s2.getColor() + s2.isFilled());
		System.out.println(s1.toString());
		System.out.println(s2.toString());
		
		Circle c1 = new Circle();
		Circle c2 = new Circle(14.0);
		Circle c3 = new Circle(7.0, "yellow", true);
		System.out.println(c1.getArea() + " " + c1.getColor() + " " + c1.getPerimeter() + " " + c1.getRadius());
		System.out.println(c2.getArea() + " " + c2.getColor() + " " + c2.getPerimeter() + " " + c2.getRadius());
		System.out.println(c3.getArea() + " " + c3.getColor() + " " + c3.getPerimeter() + " " + c3.getRadius());
		System.out.println(c1.toString());
		System.out.println(c2.toString());
		System.out.println(c3.toString());
		
		Rectangle r1 = new Rectangle();
		Rectangle r2 = new Rectangle(4.0, 2.0);
		Rectangle r3 = new Rectangle(5.0, 4.0, "black", true);
		System.out.println(r1.getWidth() + " " + r1.getLength() + " " + r1.getColor() + " " + r1.isFilled() + " " + r1.getArea() + " " + r1.getPerimeter());
		System.out.println(r2.getWidth() + " " + r2.getLength() + " " + r2.getColor() + " " + r2.isFilled() + " " + r2.getArea() + " " + r2.getPerimeter());
		System.out.println(r3.getWidth() + " " + r3.getLength() + " " + r3.getColor() + " " + r3.isFilled() + " " + r3.getArea() + " " + r3.getPerimeter());
		System.out.println(r1.toString());
		System.out.println(r2.toString());
		System.out.println(r3.toString());
		
		Square sq1 = new Square();
		Square sq2 = new Square(5.0);
		Square sq3 = new Square(4.0, "white", false);
		System.out.println(sq1.getSide() + " " + sq1.getWidth() + " " + sq1.getLength() + " " + sq1.getArea() + " " + sq1.getColor() + " " + sq1.getPerimeter() + " " + sq1.isFilled());
		System.out.println(sq2.getSide() + " " + sq2.getWidth() + " " + sq2.getLength() + " " + sq2.getArea() + " " + sq2.getColor() + " " + sq2.getPerimeter() + " " + sq2.isFilled());
		System.out.println(sq3.getSide() + " " + sq3.getWidth() + " " + sq3.getLength() + " " + sq3.getArea() + " " + sq3.getColor() + " " + sq3.getPerimeter() + " " + sq3.isFilled());
		System.out.println(sq1.toString());
		System.out.println(sq2.toString());
		System.out.println(sq3.toString());
	}
}
