import java.util.LinkedList;
public class Specimen {
	private String name;
	private int cageNumber;
	private Species toa;
	
	public Specimen(String a, int c, Species s) {
		this.name = a;
		this.cageNumber = c;
		this.toa = s;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCageNumber() {
		return cageNumber;
	}

	public void setCageNumber(int cageNumber) {
		this.cageNumber = cageNumber;
	}

	public Species getToa() {
		return toa;
	}

	public void setToa(Species toa) {
		this.toa = toa;
	}

	@Override
	public String toString() {
		return name + " is a " + toa + " in cage " + cageNumber;
	}
	void countSpecimens(Specimen[] animals, Species s) {
		int sCount = 0;
		for(int i = 0; i < animals.length; i++) {
			if(s.equals(animals[i].getToa()) || s.getSpeciesName().equals(animals[i].getToa().getSpeciesName())){
				sCount++;
			}
		}
		System.out.println(sCount);
	}
//	LinkedList makeList( Specimen [] animals ){
//		LinkedList llist = new LinkedList();
//		for (int i=0; i<animals.length; i++ ) {
//			llist.addHead( animals[i] );
//		}
//		return llist;
//	}
//	public LinkedList makeSpeciesList( LinkedList animals ) {
//		LinkedList SpeciesList = new LinkedList();
//		Specimen individual = (Specimen) animals.getHead();
//		while (individual != null) {
//			SpeciesList.addHead( individual.getToa() );
//			individual = (Specimen) animals.getNext();
//		}
//		return SpeciesList;
//	}
//	public void makeSpeciesListUnique( LinkedList allSpecies ) {
//		LinkedList uniqueSpecies = new LinkedList();
//		boolean foundType;
//		Species foundSpecies;
//		Species type = (Species) allSpecies.getHead();
//		while (type != null ) {
//			foundType = false;
//			foundSpecies = (Species) uniqueSpecies.getHead();
//			while (foundSpecies != null) {
//				if (foundSpecies == type) foundType = true;
//				foundSpecies = (Species) uniqueSpecies.getNext();
//			}
//			if ( !foundType ) uniqueSpecies.addHead( type );
//			type = (Species) allSpecies.getNext();
//		}
//		allSpecies = uniqueSpecies;
//	}
}
